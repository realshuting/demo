#!/bin/bash
echo "Starting Nirmata uninstall..."


if [ -e yaml/nirmata-services.yaml ];
then
    #Start Nirmata services uninstall
    echo "Unnstalling Nirmata services..."
    kubectl delete -f yaml/nirmata-services.yaml -n nirmata-services

    #Check if the Nirmata services are stopped
    kubectl get pods -n nirmata-services
    exit
fi
echo "Could not find Nirmata services YAML file"
