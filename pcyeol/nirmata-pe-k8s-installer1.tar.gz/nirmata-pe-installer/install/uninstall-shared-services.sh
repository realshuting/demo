#!/bin/bash
echo "Starting Nirmata uninstall..."


command_exists() {
        command -v "$@" > /dev/null 2>&1
}

if [ -e yaml/shared-services.yaml ]
then
    #Start Nirmata shared services uninstall
    echo "Unnstalling Nirmata shared services..."
    kubectl delete -f yaml/shared-services.yaml -n nirmata-shared

    #Check if the Nirmata shared services are stopped
    kubectl get pods -n nirmata-shared
    exit
fi
echo "Could not find Nirmata shared services YAML file"
