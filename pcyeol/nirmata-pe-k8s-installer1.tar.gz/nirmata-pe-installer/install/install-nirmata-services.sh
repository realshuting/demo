#!/bin/bash
echo "Starting Nirmata installation..."


command_exists() {
        command -v "$@" > /dev/null 2>&1
}

#Check for helm
helm=""
if command_exists helm; then
    helm="true"
fi

if [ -z "$helm" ]; then
    echo "Could not find helm. Please install helm and restart the installation"
    exit 0
fi


if [ -e yaml/nirmata-services.yaml ]
then
    rm yaml/nirmata-services.yaml
fi

if [ -e yaml/nirmata-services-values.yaml ]; then
    echo "Copying configuration values..."
    cp yaml/nirmata-services-values.yaml ../helm/nirmata-services/values.yaml
else 
    echo "Could not find configuration values file. Please check if it exists in the yaml folder"
    exit
fi

#Generate helm templates
echo "Generating deployment yaml..."
helm template ../helm/nirmata-services/ > yaml/nirmata-services.yaml

#Start Nirmata services installation
echo "Installing Nirmata services..."
kubectl create namespace nirmata-services
kubectl create -f yaml/nirmata-services.yaml -n nirmata-services

echo "Waiting for Nirmata services to start..."
sleep 30
#Check if the Nirmata services are up
kubectl get pods -n nirmata-services

RUNNING=$(kubectl get pods -n nirmata-services |grep Running | wc -l)
declare -i TOTAL
TOTAL=$(kubectl get pods -n nirmata-shared | wc -l)-1
echo "$RUNNING of $TOTAL pods are running"
