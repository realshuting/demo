#!/bin/bash

PARAM=$1

SOURCE_REGISTRY=index.docker.io
SOURCE_REGISTRY_USERNAME=nirmatainstaller
SOURCE_REGISTRY_PASSWORD=NirmataPE
SOURCE_REPOSITORY=nirmata
SOURCE_TAG=pe-2.1.0

TARGET_REGISTRY=
TARGET_REPOSITORY=$TARGET_REGISTRY/nirmata
TARGET_TAG=pe-2.1.0


SHARED_SERVICES=('kafka' 'kafka-es-connector' 'kibana' 'mongodb' 'elasticsearch' 'zookeeper')
NIRMATA_SERVICES=('nginx-private-edition-k8s' 'catalog' 'environments' 'webclient' 'security' 'users' 'cluster' 'imageregistry' 'config' 'orchestrator' 'host-gateway' 'nirmata-tunnel-server' 'analytics' 'cloudprovider' 'clientgateway' 'gateway' 'registry' 'nirmata-static-files')

function docker_login_source_registry {
   echo "docker login -u $SOURCE_REGISTRY_USERNAME -p ****** $SOURCE_REGISTRY"
   docker login -u $SOURCE_REGISTRY_USERNAME -p $SOURCE_REGISTRY_PASSWORD $SOURCE_REGISTRY
}

function docker_login_target_registry {
   echo "docker login -u $TARGET_REGISTRY_USERNAME -p ****** $TARGET_REGISTRY"
   docker login $TARGET_REGISTRY
}

function docker_pull {
   for (( idx=${#SERVICES[@]}-1 ; idx>=0 ; idx-- )) ; do
        docker pull $SOURCE_REPOSITORY/${SERVICES[idx]}:$SOURCE_TAG
   done
}

function docker_push {
   for (( idx=${#SERVICES[@]}-1 ; idx>=0 ; idx-- )) ; do
        if [ "$TYPE" = "backend" ]; then
           echo "docker tag $SOURCE_REPOSITORY/${SERVICES[idx]}:$SOURCE_TAG $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG"
           echo "docker push $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG"

           docker tag $SOURCE_REPOSITORY/${SERVICES[idx]}:$SOURCE_TAG $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG
           docker push $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG
        elif [ "$TYPE" = "nirmata" ]; then
           echo "docker tag $SOURCE_REPOSITORY/${SERVICES[idx]}:$SOURCE_TAG $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG"
           echo "docker push $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG"

           docker tag $SOURCE_REPOSITORY/${SERVICES[idx]}:$SOURCE_TAG $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG
           docker push $TARGET_REPOSITORY/${SERVICES[idx]}:$TARGET_TAG
        fi
   done
}

function pull_additional_images {
   docker pull nirmata/nirmata-host-agent:$SOURCE_TAG
   docker pull nirmata/nirmata-dns:$SOURCE_TAG
   docker pull nirmata/nirmata-proxy:$SOURCE_TAG
   docker pull nirmata/kubectl:1.9
   docker pull nirmata/nirmata-kube-installer:1.9
   docker pull nirmata/nirmata-cni-installer:1.9
   docker pull nirmata/nirmata-kube-controller:$SOURCE_TAG
   docker pull nirmata/amazon-k8s-cni:0.1.3
}

function push_additional_images {
   docker tag nirmata/nirmata-host-agent:latest $TARGET_REPOSITORY/nirmata-host-agent:$TARGET_TAG
   docker tag nirmata/nirmata-dns:latest $TARGET_REPOSITORY/nirmata-dns:$TARGET_TAG
   docker tag nirmata/nirmata-proxy:latest $TARGET_REPOSITORY/nirmata-proxy:$TARGET_TAG
   docker tag nirmata/kubectl:1.9 $TARGET_REPOSITORY/kubectl:1.9
   docker tag nirmata/nirmata-kube-installer:1.9 $TARGET_REPOSITORY/nirmata-kube-installer:1.9
   docker tag nirmata/nirmata-cni-installer:1.9 $TARGET_REPOSITORY/nirmata-cni-installer:1.9
   docker tag nirmata/nirmata-kube-controller:$SOURCE_TAG $TARGET_REPOSITORY/nirmata-kube-controller:$TARGET_TAG
   docker tag nirmata/amazon-k8s-cni:0.1.3 $TARGET_REPOSITORY/amazon-k8s-cni:0.1.3

   docker push $TARGET_REPOSITORY/nirmata-host-agent:$TARGET_TAG
   docker push $TARGET_REPOSITORY/nirmata-dns:$TARGET_TAG
   docker push $TARGET_REPOSITORY/nirmata-proxy:$TARGET_TAG
   docker push $TARGET_REPOSITORY/kubectl:1.9
   docker push $TARGET_REPOSITORY/nirmata-kube-installer:1.9
   docker push $TARGET_REPOSITORY/nirmata-cni-installer:1.9
   docker push $TARGET_REPOSITORY/nirmata-kube-controller:$TARGET_TAG
   docker push $TARGET_REPOSITORY/amazon-k8s-cni:0.1.3
}

function pull_images {
   docker_login_source_registry

   TYPE=backend
   SERVICES=("${SHARED_SERVICES[@]}")
   TAG=$SOURCE_TAG
   docker_pull

   TYPE=nirmata
   SERVICES=("${NIRMATA_SERVICES[@]}")
   TAG=$SOURCE_TAG
   docker_pull

   pull_additional_images
}

function push_images {
   docker_login_target_registry

   TYPE=backend
   SERVICES=("${SHARED_SERVICES[@]}")
   TAG=$SOURCE_TAG
   docker_push

   TYPE=nirmata
   SERVICES=("${NIRMATA_SERVICES[@]}")
   TAG=$SOURCE_TAG
   docker_push

   push_additional_images
}

if [ "$PARAM" != "nopull" ]; then
   pull_images
fi

push_images
