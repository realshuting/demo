#!/bin/bash
echo "Starting Nirmata installation..."


command_exists() {
        command -v "$@" > /dev/null 2>&1
}

#Check for helm
helm=""
if command_exists helm; then
    helm="true"
fi

if [ -z "$helm" ]; then
    echo "Could not find helm. Please install helm and restart the installation"
    exit 0
fi


if [ -e yaml/shared-services.yaml ]; then
    rm yaml/shared-services.yaml
fi

if [ -e yaml/shared-services-values.yaml ]; then
    echo "Copying configuration values..."
    cp yaml/shared-services-values.yaml ../helm/nirmata-shared/values.yaml
else 
    echo "Could not find configuration values file. Please check if it exists in the yaml folder"
    exit
fi

#Generate helm templates
echo "Generating deployment yaml..."
helm template ../helm/nirmata-shared/ > yaml/shared-services.yaml

#Start shared services installation
echo "Installing shared services..."
kubectl create namespace nirmata-shared
kubectl create -f yaml/shared-services.yaml -n nirmata-shared

echo "Waiting for shared services to start..."
sleep 30
#Check if the shared services are up
kubectl get pods -n nirmata-shared

RUNNING=$(kubectl get pods -n nirmata-shared |grep Running | wc -l)
declare -i TOTAL
TOTAL=$(kubectl get pods -n nirmata-shared | wc -l)-1
echo "$RUNNING of $TOTAL pods are running"
