#!/bin/bash
if [ -z "$NIRMATA_URL" ]; then
    echo "Please provide the Nirmata URL. You can export it as an environment variable: NIRMATA_URL"
    exit
fi
if [ -z "$APIKEY" ]; then
    echo "Please provide the API Key. You can export it as an environment variable: APIKEY"
    exit
fi
function show_usage {
    echo "Usage: delete-running-application.sh <application-name>"
}

RUN_NAME=$1
if [ -z "$RUN_NAME" ]; then
    show_usage
    exit
fi

echo "Deleting application $RUN_NAME..."

#echo curl -v -s -k -H "Content-Type: application/json" -H "Authorization:  NIRMATA-API $APIKEY" -H "Accept: application/json, text/javascript, */*; q=0.01" -X GET $NIRMATA_URL/environments/api/Application --data-urlencode 'query={"run":"'"$RUN_NAME"'"}&fields=id'

APPLICATION_ID=$(curl -s -H "Content-Type: application/json" -H "Authorization:  NIRMATA-API $APIKEY" -H "Accept: application/json, text/javascript, */*; q=0.01" -X GET $NIRMATA_URL/environments/api/Application -G  --data-urlencode 'query={"run":"'"$RUN_NAME"'"}' --data-urlencode 'fields=id' |jq --raw-output '.[0] .id')
echo "$APPLICATION_ID"

echo curl -s -H "Content-Type: text/yaml" -H "Authorization: NIRMATA-API $APIKEY" -X DELETE $NIRMATA_URL/environments/api/Application/$APPLICATION_ID

RUN=$(curl -s -H "Content-Type: text/yaml" -H "Authorization: NIRMATA-API $APIKEY" -X DELETE $NIRMATA_URL/environments/api/Application/$APPLICATION_ID)
echo "Response: $RUN"
