#!/bin/bash

if [ -z "$NIRMATA_URL" ]; then
    echo "Please provide the Nirmata URL. You can export it as an environment variable: NIRMATA_URL"
    exit
fi
if [ -z "$APIKEY" ]; then
    echo "Please provide the API Key. You can export it as an environment variable: APIKEY"
    exit
fi

function show_usage {
    echo "Usage: deploy-catalog-application.sh <catalog-application-name> <running-application-name> <environment-name>"
}

CATALOG_APP=$1
RUN_NAME=$2
ENVIRONMENT=$3

if [ -z "$CATALOG_APP" ]; then
    show_usage
    exit
fi

if [ -z "$RUN_NAME" ]; then
    show_usage
    exit
fi

if [ -z "$ENVIRONMENT" ]; then
    show_usage
    exit
fi

echo "Getting app $CATALOG_APP..."

#For debugging
#echo curl -v -s -k -H "Content-Type: application/json" -H "Authorization:  NIRMATA-API $APIKEY" -H "Accept: application/json, text/javascript, */*; q=0.01" -X GET $NIRMATA_URL/catalog/api/Application --data-urlencode 'query={"name":"'"$CATALOG_APP"'"}&fields=id'

APPLICATION_ID=$(curl -s -H "Content-Type: application/json" -H "Authorization:  NIRMATA-API $APIKEY" -H "Accept: application/json, text/javascript, */*; q=0.01" -X GET $NIRMATA_URL/catalog/api/Application -G  --data-urlencode 'query={"name":"'"$CATALOG_APP"'"}' --data-urlencode 'fields=id' |jq --raw-output '.[0] .id')
echo "$APPLICATION_ID"

RUN=$(curl -s -H "Content-Type: application/json" -H "Authorization:  NIRMATA-API $APIKEY" -H "Accept: application/json, text/javascript, */*; q=0.01" -X POST $NIRMATA_URL/catalog/api/Application/$APPLICATION_ID/run -d '{
    "run": "'"$RUN_NAME"'",
    "environment":  "'"$ENVIRONMENT"'"
}')
echo "Response $RUN"
